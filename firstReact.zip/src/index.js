import React from "react";
import ReactDom from "react-dom";

ReactDom.render(
  <React.Fragment>
    <h1>Netflix Top Series</h1>
    <p>Best five series</p>
    <ol>
      <li>Mank</li>
      <li>The King</li>
      <li>Crazy About Her</li>
      <li>The Paramedic</li>
      <li>The Kissing Booth</li>
    </ol>
  </React.Fragment>,
  document.getElementById("root")
);
