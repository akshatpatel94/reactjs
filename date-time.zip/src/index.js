import React from "react";
import ReactDom from "react-dom";
// import DateTime from "react-datetime";

let name = "Akshat Patel";
let currDate = new Date().toLocaleDateString();
let currTime = new Date().toLocaleTimeString();

ReactDom.render(
  <>
    <h1>My name is {name}</h1>
    <p>Current Date : {currDate}</p>
    <p>Current Time : {currTime} </p>
  </>,
  document.getElementById("root")
);
